import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { Loader2, Pencil, Trash2 } from "lucide-react";
import { getMatchScoreBand } from "../../../utils/matchScore";

/**
 * Presentational card for a single report. Emits click intents via props;
 * never calls the backend or contains business logic itself.
 */
export default function ReportCard({ report, onOpen, onRename, onDelete, isBusy }) {
  const band = getMatchScoreBand(report.matchScore);

  const stopPropagation = (event, callback) => {
    event.stopPropagation();
    callback();
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className="group rounded-2xl bg-gradient-to-br from-[#970747]/40 via-[#EAA7C4]/50 to-[#D65795]/40 p-[1px] shadow-sm transition-shadow hover:shadow-[0_20px_45px_-20px_rgba(151,7,71,0.4)]"
    >
      <button
        type="button"
        onClick={() => onOpen(report._id)}
        className="flex h-full w-full flex-col rounded-[15px] bg-white p-5 text-left"
      >
        <div className="flex items-start justify-between gap-3">
          <h3 className="line-clamp-2 text-base font-semibold text-[#1F1F1F]">{report.title}</h3>
          <span
            className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${band.bg} ${band.text}`}
          >
            {report.matchScore ?? 0}%
          </span>
        </div>

        <p className={`mt-1 text-xs font-medium ${band.text}`}>{band.short} Match</p>

        <div className="mt-4 flex flex-1 items-end justify-between gap-2 text-xs text-[#666666]">
          <div>
            <p>Created {formatDistanceToNow(new Date(report.createdAt), { addSuffix: true })}</p>
            <p className="mt-0.5">
              Updated {formatDistanceToNow(new Date(report.updatedAt), { addSuffix: true })}
            </p>
          </div>

          <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
            {isBusy ? (
              <Loader2 size={16} className="animate-spin text-[#970747]" />
            ) : (
              <>
                <span
                  role="button"
                  tabIndex={0}
                  aria-label="Rename report"
                  onClick={(event) => stopPropagation(event, () => onRename(report))}
                  onKeyDown={(event) =>
                    event.key === "Enter" && stopPropagation(event, () => onRename(report))
                  }
                  className="flex h-8 w-8 items-center justify-center rounded-full text-[#666666] transition hover:bg-[#FAF8FB] hover:text-[#970747]"
                >
                  <Pencil size={14} />
                </span>
                <span
                  role="button"
                  tabIndex={0}
                  aria-label="Delete report"
                  onClick={(event) => stopPropagation(event, () => onDelete(report))}
                  onKeyDown={(event) =>
                    event.key === "Enter" && stopPropagation(event, () => onDelete(report))
                  }
                  className="flex h-8 w-8 items-center justify-center rounded-full text-[#666666] transition hover:bg-red-50 hover:text-[#FF3B30]"
                >
                  <Trash2 size={14} />
                </span>
              </>
            )}
          </div>
        </div>
      </button>
    </motion.div>
  );
}