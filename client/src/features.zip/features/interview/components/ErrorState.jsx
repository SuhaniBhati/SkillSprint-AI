import { motion } from "framer-motion";
import { AlertTriangle, RefreshCcw } from "lucide-react";

/**
 * Generic error state for API failures (report list, single report, etc).
 * Purely presentational - the retry callback is supplied by the page/hook.
 */
export default function ErrorState({
  title = "Something went wrong",
  message = "We couldn't complete this request. Please try again.",
  onRetry,
  retryLabel = "Try Again",
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
      className="flex flex-col items-center justify-center rounded-3xl border border-[#ECE5EA] bg-white px-6 py-16 text-center"
    >
      <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-red-50">
        <AlertTriangle size={34} strokeWidth={1.5} className="text-[#FF3B30]" />
      </div>
      <h3 className="text-lg font-semibold text-[#1F1F1F]">{title}</h3>
      <p className="mt-2 max-w-sm text-sm text-[#666666]">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#ECE5EA] bg-[#FAF8FB] px-5 py-2.5 text-sm font-semibold text-[#1F1F1F] transition hover:bg-white hover:shadow-sm active:scale-95"
        >
          <RefreshCcw size={15} />
          {retryLabel}
        </button>
      )}
    </motion.div>
  );
}