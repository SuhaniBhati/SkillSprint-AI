import { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, Sparkles } from "lucide-react";
import ResumeUpload from "./ResumeUpload";

/**
 * Composes the "generate report" form. Local component state only tracks
 * raw field values; submission and all business rules live in
 * useGenerateReport, invoked through onSubmit.
 */
export default function GenerateReportForm({ onSubmit, isGenerating, uploadProgress, error }) {
  const [resume, setResume] = useState(null);
  const [jobDescription, setJobDescription] = useState("");
  const [selfDescription, setSelfDescription] = useState("");
  const [fieldError, setFieldError] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    setFieldError(null);
    onSubmit({ resume, jobDescription, selfDescription });
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      onSubmit={handleSubmit}
      className="space-y-6 rounded-3xl border border-[#ECE5EA] bg-white p-6 shadow-sm sm:p-8"
    >
      <div>
        <label className="mb-2 block text-sm font-semibold text-[#1F1F1F]">Resume</label>
        <ResumeUpload
          file={resume}
          onFileSelect={setResume}
          onRemove={() => setResume(null)}
          onError={setFieldError}
        />
      </div>

      <div>
        <label htmlFor="jobDescription" className="mb-2 block text-sm font-semibold text-[#1F1F1F]">
          Job Description
        </label>
        <textarea
          id="jobDescription"
          value={jobDescription}
          onChange={(event) => setJobDescription(event.target.value)}
          rows={6}
          placeholder="Paste the job description you're preparing for..."
          className="w-full resize-none rounded-2xl border border-[#ECE5EA] bg-[#FAF8FB] p-4 text-sm text-[#1F1F1F] outline-none transition placeholder:text-[#999999] focus:border-[#C74D81] focus:ring-4 focus:ring-[#EAA7C4]/30"
        />
      </div>

      <div>
        <label htmlFor="selfDescription" className="mb-2 block text-sm font-semibold text-[#1F1F1F]">
          About You <span className="font-normal text-[#666666]">(optional)</span>
        </label>
        <textarea
          id="selfDescription"
          value={selfDescription}
          onChange={(event) => setSelfDescription(event.target.value)}
          rows={4}
          placeholder="Share anything you'd like the interviewer to know about you..."
          className="w-full resize-none rounded-2xl border border-[#ECE5EA] bg-[#FAF8FB] p-4 text-sm text-[#1F1F1F] outline-none transition placeholder:text-[#999999] focus:border-[#C74D81] focus:ring-4 focus:ring-[#EAA7C4]/30"
        />
      </div>

      {(fieldError || error) && (
        <p className="rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-[#FF3B30]">
          {fieldError || error}
        </p>
      )}

      {isGenerating && (
        <div>
          <div className="mb-1.5 flex justify-between text-xs font-medium text-[#666666]">
            <span>Uploading resume</span>
            <span>{uploadProgress}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-[#ECE5EA]">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-[#970747] to-[#D65795]"
              animate={{ width: `${uploadProgress}%` }}
              transition={{ ease: "easeOut", duration: 0.3 }}
            />
          </div>
        </div>
      )}

      <button
        type="submit"
        disabled={isGenerating}
        className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#970747] to-[#D65795] px-6 py-3.5 text-sm font-semibold text-white shadow-md transition hover:shadow-lg active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-70"
      >
        {isGenerating ? (
          <>
            <Loader2 size={16} className="animate-spin" />
            Generating Report...
          </>
        ) : (
          <>
            <Sparkles size={16} />
            Generate Report
          </>
        )}
      </button>
    </motion.form>
  );
}